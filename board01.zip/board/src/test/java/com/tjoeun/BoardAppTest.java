package com.tjoeun;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.tjoeun.entity.Question;
import com.tjoeun.repository.QuestionRepository;

@SpringBootTest
// @Transactional
class BoardAppTest {
	
	@Autowired
	private QuestionRepository questionRepository; 

	@Test
	@DisplayName("질문 테스트 - 1")
	void questionTest() {
		Question q1 = new Question();
		q1.setSubject("Spring Boot ???");
		q1.setContent("Spring Boot 에 대해서 알고 싶습니다");
		q1.setCreateDate(LocalDateTime.now());
		questionRepository.save(q1);
		
		Question q2 = new Question();
		q2.setSubject("Querydsl ???");
		q2.setContent("Querydsl 에 대해서 알고 싶습니다");
		q2.setCreateDate(LocalDateTime.now());
		questionRepository.save(q2);
		
	}
	
	@Test
	@DisplayName("조회 테스트 - 1")
	void selectTest1() {
		List<Question> questionList = questionRepository.findAll();
		
		assertEquals(2, questionList.size());
		
		Question q1 = questionList.get(0);
		assertEquals("Spring Boot ???", q1.getSubject());
		
	}
	
	@Test
	@DisplayName("조회 테스트 - 2")
	void selectTest2() {
		
		Optional<Question> questionOne = questionRepository.findById((long)2);
		
		if(questionOne.isPresent()) {
			Question q1 = questionOne.get();			
			assertEquals("Querydsl ???", q1.getSubject());			
			
		}
	}
	
	@Test
	@DisplayName("조회 테스트 - 3")
	void selectTest3() {
		Question q1 = questionRepository.findBySubjectAndContent("Spring Boot ???", "Spring Boot 에 대해서 알고 싶습니다");
		assertEquals(1, q1.getId());
	}
	
	@Test
	@DisplayName("조회 테스트 - 4")
	void selectTest4() {
		List<Question> questionList = questionRepository.findBySubjectLike("Spr%%");
		
		// assertEquals(1, questionList.get(0).getId());		
		
		Question q1 = questionList.get(0);
		assertEquals(1, q1.getId());
	}
	
	@Test
	@DisplayName("수정 테스트 - 1")
	void updateTest1() {
		Optional<Question> q1 = questionRepository.findById((long)1);
		
		assertTrue(q1.isPresent());
			
		Question question = q1.get();
		question.setSubject("Spring Board ???");
		questionRepository.save(question);
		
	}
	
	@Test
	@DisplayName("삭제 테스트 - 1")
	void deleteTest1() {
		
		assertEquals(2, questionRepository.count());
		
		Optional<Question> q1 = questionRepository.findById((long)1);
		assertTrue(q1.isPresent());
		Question question = q1.get();
		questionRepository.delete(question);
		
		assertEquals(1, questionRepository.count());
		
	}
	
}








