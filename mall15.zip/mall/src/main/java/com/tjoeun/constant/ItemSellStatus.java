package com.tjoeun.constant;

public enum ItemSellStatus {
	SELL, SOLD_OUT
}
