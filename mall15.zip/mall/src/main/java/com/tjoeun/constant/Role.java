package com.tjoeun.constant;

public enum Role {
  USER, ADMIN
}
