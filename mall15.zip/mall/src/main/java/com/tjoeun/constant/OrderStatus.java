package com.tjoeun.constant;

public enum OrderStatus {
  ORDER, CANCEL
}
