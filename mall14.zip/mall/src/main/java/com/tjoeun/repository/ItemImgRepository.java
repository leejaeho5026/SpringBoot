package com.tjoeun.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tjoeun.entity.ItemImg;

public interface ItemImgRepository extends JpaRepository<ItemImg, Long>{
	
}
