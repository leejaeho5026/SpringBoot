package com.tjoeun.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.tjoeun.dto.ItemFormDto;

@Controller
public class ItemController {

	@GetMapping("/admin/item/new")
  public String intemForm(ItemFormDto itemFormDto) {
		return "item/itemForm";
	}
	
	/*
	@GetMapping("/admin/item/new")
  public String intemForm(ItemFormDto itemFormDto, Model model) {
		model.addAttribute("itemFormDto", itemFormDto);
		return "item/itemForm";
	}
	
	@GetMapping("/admin/item/new")
	public String intemForm(Model model) {
		model.addAttribute("itemFormDto", new ItemFormDto());
		return "item/itemForm";
	}
	*/
	
	
}
