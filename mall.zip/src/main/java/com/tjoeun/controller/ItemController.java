package com.tjoeun.controller;

import java.util.List;

import javax.validation.Valid;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.tjoeun.dto.ItemFormDto;
import com.tjoeun.service.ItemService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class ItemController {

	//@RequiredArgsConstructor
	private final ItemService itemService;
	
	//@Autowired 
	// private ItemService itemSerivce
	
	
	
	@GetMapping("/admin/item/new")
  public String intemForm(ItemFormDto itemFormDto) {
		return "item/itemForm";
	}

	
	/*
	@GetMapping("/admin/item/new")
  public String intemForm(ItemFormDto itemFormDto, Model model) {
		model.addAttribute("itemFormDto", itemFormDto);
		return "item/itemForm";
	}
	
	@GetMapping("/admin/item/new")
	public String intemForm(Model model) {
		model.addAttribute("itemFormDto", new ItemFormDto());
		return "item/itemForm";
	}
	*/
	
	//JSP에서 name = ""속성으로 보낸 값을 RequestParam으로 받는다.
	//List로 보내서 List로 받아야함
	@PostMapping("/admin/item/new")
	public String itemNew(@Valid  ItemFormDto itemFormDto, BindingResult result, Model model,
											@RequestParam("itemImgFileList") List<MultipartFile> itemImgFileList) {
																		
		if(result.hasErrors()) {
			return "item/itemForm"; //오류가 났을 때 itemForm페이지로 다시 이동
		}
		// 상품 이미지를 선택하지 않고 상품 저장을 누른 경우
		//List<MultipartFile> itemImgFileList 인덱스가 0이면 사진이 없는 거
		// 상품 이미지는 최소한 하나는 올리도록 설정
		//하나도 선택을 안 하고 올리면 에러메세지 팝업창으로  띄움 (자바스크립트로)
		if(itemImgFileList.get(0).isEmpty() && itemFormDto.getId() == null){
			model.addAttribute("errorMessage", "첫 번째 상품 이미지는 반드시 업로드하세요.");
			return "item/itemForm";
		}
		
		try {
			itemService.saveItem(itemFormDto, itemImgFileList);
		} catch (Exception e) {
			model.addAttribute("errorMessage", "상품 등록 중 오류발생");
		}
		//성공하면 메인화면으로 바로 이동
		return "redirect:/";
	}
	
	
	
}
