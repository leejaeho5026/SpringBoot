package com.tjoeun.dto;

import com.tjoeun.entity.BaseEntity;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ItemDto extends BaseEntity{

	private Long id; // 상품 코드

	private String itemNm; // 상품 이름

	private int price; // 상품 가격

	private int stockNumber; // 재고 수량

	private String itemDetail; // 상품 상세 설명

	private String itemSellStatus;  // 판매 상태


	// BaseEntity에 있는 regTime과 updateTime을 상속받아서 사용 ( extends BaseEntity)
	
	
}
