package com.tjoeun.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.tjoeun.dto.ItemFormDto;
import com.tjoeun.entity.Item;
import com.tjoeun.entity.ItemImg;
import com.tjoeun.repository.ItemImgRepository;
import com.tjoeun.repository.ItemRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class ItemService {

	private final ItemRepository itemRepository;
	private final ItemImgRepository itemImgRepository;
	private final ItemImgService itemImgService;

	// item을 등록하면 item id가 넘어옴
	// itemDto와 MultipartFile를 Generic으로 하는 List를 파라미터로 전달받음 List<MultipartFile> itemImgFileList
	// itemImgFileList : 등록한 이미지 파일들을 List로 가져옴
	// itemFormDto : front단에서 입력한 data를 저장해서 Server단으로 가져옴
	
	//아이템을 저장할 때 이미지도 같이 저장
	public Long saveItem(ItemFormDto itemFormDto, List<MultipartFile> itemImgFileList) throws Exception {
		
		//상품 등록
		//itemFormDto.createItem()에서 mapper를 사용해서
		//dto를 entity로 바꾼 Item(entity)객체를 받아옴
		Item item = itemFormDto.createItem();

		//DB에 저장함 : 이미지 번호(id)가 생김
		//Item item변수에 할당하지 않아도  consistence영역에 저장되어서 값을 확인 할 수 있다.
		//return item.getId() : 업로드한 상품번호 (id) -> 행의 Item item와 같은 item
		itemRepository.save(item);
		
		//이미지 등록 : 저장한 이미지 개수만큼 등록함
		for(int i=0; i<itemImgFileList.size(); i++ ) {
			// ItemImg는 Entitiy
			// item image등록을 위해서 ItemImg객체를 생성함
			ItemImg itemImg = new ItemImg();
		
			// persistence 영역에서 있는 item 객체를 setItem으로 저장함
			// id값을 사용하게 됨 -> foreign key가 설정된다.
			// 몇 번째 등록인지를 image에 설정함 : 1번째면 아래 it문에서 대표 이미지로 설정
			itemImg.setItem(item); //Item item이다. (DTO)
		
			//1번째 이미지를 대표 이미지로 설정
			if(i==0) {
				itemImg.setRepImgYn("Y");
			}else {
				itemImg.setRepImgYn("N");
			}
			//이미지를 DB에 저장함							//itemFormDto, 	MultipartFile.get(index)
			itemImgService.saveItemImg(itemImg,itemImgFileList.get(i));
		
		}
		
		//item의 id를 반환함
		return item.getId(); 
	
	
	}

}
