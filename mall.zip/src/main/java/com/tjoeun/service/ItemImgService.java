package com.tjoeun.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.thymeleaf.util.StringUtils;

import com.tjoeun.entity.ItemImg;
import com.tjoeun.repository.ItemImgRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional //문제가 생기면 롤백, 안 생기면 커밋
@RequiredArgsConstructor
public class ItemImgService {
	//ItemImgRepository를 사용하기 위해서 가져옴, ItemImgRepository에 있는 메소드 사용가능
	
	//롬복 임포트 X   ->  springframework로 임포트
	@Value("{itemImgLocation}")
	private String itemImgLocation;
	
	private final ItemImgRepository itemImgRepository;
	
	private final FileService fileService;
	
	//이미지 저장하는 메소드
	public void saveItemImg(ItemImg itemImg, MultipartFile itemImgFile) throws Exception {
		
		// MultpartFile itemImgFile에 원래 파일 이름 정보가 있음
		// 실제 이미지를 다운로드 할 때는 원래 파일이름으로 다운로드함
		String oriImgName = itemImgFile.getOriginalFilename(); 
		
		//파일 이름
		String imgName = "";
		
		//이미지 경로
		String imgUrl = "";
		
		//파일 업로드 : oriImgName에 내용이 있는지 확인함
		//thymeleaf의 StringUtils를 사용해서 원래 경로 값이 없는지(빈문자열인지) 확인
		if(!StringUtils.isEmpty(oriImgName)) {
		//orImgName이 있는 경우 
		// fileService.uploadFile()을 호출해서 실제 이미지 이름을 받아옴
		//이미지 파일 정보가 있는 itemImgFile에서 이 정보를 byte 배열로 가져옴
		 imgName = 	fileService.uploadFile(itemImgLocation, oriImgName, itemImgFile.getBytes());
		//아래와 같이 설정하면 실제 업로드한 이름으로 접근할 수 있음
		 imgUrl = "/images/item" + imgName; 
		
		}
		//이미지를 변경하는 경우 상품 이미지 정보 저장
		itemImg.updateImg(imgName, oriImgName, imgUrl);
		
		//실제 DB에 저장함
		itemImgRepository.save(itemImg);
		
	}
	

}
