package com.tjoeun.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tjoeun.entity.OrderItem;
																										//<T(클래스) , ID타입>
public interface OrderItemRepository extends JpaRepository<OrderItem, Long>{

}
