package com.tjoeun.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tjoeun.entity.Cart;
																						 //<T(클래스) , ID타입>
public interface CartRepository extends JpaRepository<Cart, Long>{

}
