package com.tjoeun.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

//설정 클래스이기 때문에 @Configuration 사용
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

	@Value("${uploadPath}")
	private String uploadPath;
	
	//addResourceHandlers() <- resource를  handling하는 메소드

	
	// addResourceHandlers로 자동완성
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {

		//resources.static폴더안에 (/)
		registry.addResourceHandler("/images/**") //project내부 경로 - web에서 접근 경로 - logical path
					.addResourceLocations(uploadPath); //실제 PC(Server)에서의 경로 - physical path
	}
	
}
