package com.tjoeun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardApp {

	public static void main(String[] args) {
		SpringApplication.run(BoardApp.class, args);
	}

}
