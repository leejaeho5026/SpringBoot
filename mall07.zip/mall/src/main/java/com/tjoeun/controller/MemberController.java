package com.tjoeun.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tjoeun.dto.MemberFormDto;

import lombok.extern.log4j.Log4j2;

@Controller
@RequestMapping("/member")
@Log4j2
public class MemberController {

	// localhost:8787/member/new
	@GetMapping("/new")
	public String memberForm(MemberFormDto memberFormDto) {
		return "member/memberForm";
	}
	/*
	@GetMapping("/new")
	public String memberForm2(Model model) {
	  model.addAttribute("memberFormDto", new MemberFormDto());	  
		return "member/memberForm";
	}
	
	@GetMapping("/new")
	public String memberForm3(MemberFormDto memberFormDto, Model model) {
	  model.addAttribute("memberFormDto", memberFormDto);	  
		return "member/memberForm";
	}
	*/
	
	@PostMapping("/new")
	public String memberForm() {
		log.info(">>>>>>>>>>>> 회원가입 완료");
		return "redirect:/";
	}
	
	
}
